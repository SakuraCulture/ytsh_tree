package me.ele.retail.param;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;

public class MeEleRetailSaasOrderListDetailResDto {

    private String order_id;

    /**
     * @return 订单id
     */
    public String getOrder_id() {
        return order_id;
    }

    /**
     * 设置订单id     *
     * 参数示例：<pre>5000000040440050260</pre>     
     * 此参数必填
     */
    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    private Integer status;

    /**
     * @return 订单状态，1（已支付）、2（已接单）、3（已拣货）、4（已打包）、5（已发货）、6（交易成功）、-1（交易关闭）
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置订单状态，1（已支付）、2（已接单）、3（已拣货）、4（已打包）、5（已发货）、6（交易成功）、-1（交易关闭）     *
     * 参数示例：<pre>1</pre>     
     * 此参数必填
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    private Long create_time;

    /**
     * @return 订单创建时间，格式：unix时间戳（秒级）
     */
    public Long getCreate_time() {
        return create_time;
    }

    /**
     * 设置订单创建时间，格式：unix时间戳（秒级）     *
     * 参数示例：<pre>1718786539</pre>     
     * 此参数必填
     */
    public void setCreate_time(Long create_time) {
        this.create_time = create_time;
    }

}
